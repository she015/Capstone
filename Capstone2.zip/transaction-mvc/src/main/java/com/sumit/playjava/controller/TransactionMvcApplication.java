package com.sumit.playjava.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionMvcApplication.class, args);
	}

}
